import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.cluster import KMeans


X = [[0.1,0.6],[0.2,0.5],[0.08,0.9],[0.16,0.85],[0.2,0.3],[0.25,0.5],[0.1,0.6],[0.3,0.2]]

print(X)

centroids = np.array([[0.1,0.6],[0.3,0.2]])

model = KMeans(n_clusters=2)

model.fit(X)

labels = model.labels_

# Refer problem from syllabus to understand the questions

print(labels)
print('p6 belogs to cluster :',model.labels_[6])
	
count=0
for i in range(len(labels)):
    if (labels[i]==1):
        count=count+1

print('No of population around cluster 2:',np.count_nonzero(model.labels_ == 1))

print('Previous value of m1 and m2 is:')
print('M1==',centroids[0])
print('M2==',centroids[1])

new_centroids = model.cluster_centers_

print('updated value of m1 and m2 is:')
print('M1==',new_centroids[0])
print('M2==',new_centroids[1])



